package com.inventryitem.inventryitem.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.inventryitem.inventryitem.model.Inventory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MyDatabase.db";
    private static final int DATABASE_VERSION = 1;

    private static final String INVENTORY_TABLE = "inventory";
    public static final String INVENTORY_COLUMN_ID = "_id";
    public static final String INVENTORY_COLUMN_NAME = "name";
    public static final String INVENTORY_COLUMN_QUANTITY = "quantity";
    public static final String INVENTORY_COLUMN_PRICE = "price";
    public static final String INVENTORY_COLUMN_EDIT = "edit_clm";
    public static final String INVENTORY_COLUMN_DELETE = "delete_clm";
    public static final String INVENTORY_COLUMN_USER_ID = "user_id";

    // Registration table and column names
    private static final String REGISTRATION_TABLE = "registration";
    private static final String REGISTRATION_COLUMN_ID = "id";
    private static final String REGISTRATION_COLUMN_USERNAME = "username";
    private static final String REGISTRATION_COLUMN_PASSWORD = "password";

    private static DatabaseHelper instance;

    // Private constructor to enforce Singleton pattern
    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Get the single instance of the DatabaseHelper
    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create table
        String createTable = "CREATE TABLE IF NOT EXISTS " + INVENTORY_TABLE + " ("
                + INVENTORY_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + INVENTORY_COLUMN_NAME + " VARCHAR, "
                + INVENTORY_COLUMN_PRICE + " VARCHAR, "
                + INVENTORY_COLUMN_QUANTITY + " VARCHAR, "
                + INVENTORY_COLUMN_EDIT + " VARCHAR, "
                + INVENTORY_COLUMN_DELETE + " VARCHAR, "
                + INVENTORY_COLUMN_USER_ID + " VARCHAR);";
        db.execSQL(createTable);

        // Create Registration table
        String createRegistrationTable = "CREATE TABLE IF NOT EXISTS " + REGISTRATION_TABLE + " ("
                + REGISTRATION_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + REGISTRATION_COLUMN_USERNAME + " VARCHAR UNIQUE, "
                + REGISTRATION_COLUMN_PASSWORD + " VARCHAR);";
        db.execSQL(createRegistrationTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop table if exists and recreate (only for schema changes)
        db.execSQL("DROP TABLE IF EXISTS " + INVENTORY_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + REGISTRATION_TABLE);
        onCreate(db);
    }

    // Insert data into the database
    /**
     * Inventory Methods
     * */

    public Cursor fetchData(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(
                INVENTORY_TABLE,                     // Table name
                null,                                // Select all columns
                INVENTORY_COLUMN_USER_ID + " = ?",        // WHERE clause
                new String[]{String.valueOf(userId)}, // WHERE arguments
                null,                                // GROUP BY
                null,                                // HAVING
                null                                 // Default ORDER BY
        );
    }

    public List<Inventory> fetchInventoryList(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                INVENTORY_TABLE,                     // Table name
                null,                                // Select all columns
                INVENTORY_COLUMN_USER_ID + " = ?",   // WHERE clause
                new String[]{String.valueOf(userId)},// WHERE arguments
                null,                                // GROUP BY
                null,                                // HAVING
                null                                 // Default ORDER BY
        );

        List<Inventory> inventoryList = new ArrayList<>();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                // Retrieve data from cursor
                @SuppressLint("Range") String id = cursor.getString(cursor.getColumnIndex(INVENTORY_COLUMN_ID));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(INVENTORY_COLUMN_NAME));
                @SuppressLint("Range") String quantity = cursor.getString(cursor.getColumnIndex(INVENTORY_COLUMN_QUANTITY));
                @SuppressLint("Range") String price = cursor.getString(cursor.getColumnIndex(INVENTORY_COLUMN_PRICE));

                // Create an Inventory object and add it to the list
                Inventory inventory = new Inventory(id, name, price, quantity);
                inventoryList.add(inventory);
            } while (cursor.moveToNext());

            cursor.close();
        }

        return inventoryList;
    }


    public Inventory getInventoryById(String inventoryId) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Query the database for the inventory with the specified ID
        Cursor cursor = db.query(
                INVENTORY_TABLE,                     // Table name
                null,                                // Columns (null to fetch all columns)
                INVENTORY_COLUMN_ID + " = ?",        // WHERE clause
                new String[]{inventoryId}, // WHERE arguments
                null,                                // Group by
                null,                                // Having
                null                                 // Order by
        );

        Inventory inventory = null;

        // If a row is found, create an Inventory object
        if (cursor != null && cursor.moveToFirst()) {
            String id = cursor.getString(cursor.getColumnIndexOrThrow(INVENTORY_COLUMN_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(INVENTORY_COLUMN_NAME));
            String quantity = cursor.getString(cursor.getColumnIndexOrThrow(INVENTORY_COLUMN_QUANTITY));
            String price = cursor.getString(cursor.getColumnIndexOrThrow(INVENTORY_COLUMN_PRICE));

            inventory = new Inventory(id, name, price, quantity);
        }

        // Close the cursor and database connection
        if (cursor != null) cursor.close();
        db.close();

        return inventory;
    }

    public long addInventory(String name, String quantity, String price, String userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(INVENTORY_COLUMN_NAME, name);
        values.put(INVENTORY_COLUMN_QUANTITY, quantity);
        values.put(INVENTORY_COLUMN_PRICE, price);
        values.put(INVENTORY_COLUMN_EDIT, "Edit");
        values.put(INVENTORY_COLUMN_DELETE, "Delete");
        values.put(INVENTORY_COLUMN_USER_ID, userId);

        // Insert row and return the new row's ID
        return db.insert(INVENTORY_TABLE, null, values);
    }

    public long updateInventory(String itemId, String name, String quantity, String price) {

        SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(INVENTORY_COLUMN_NAME, name);
            values.put(INVENTORY_COLUMN_QUANTITY, quantity);
            values.put(INVENTORY_COLUMN_PRICE, price);

            int rowsUpdated = db.update(
                    INVENTORY_TABLE,
                    values,
                    INVENTORY_COLUMN_ID + "=?",
                    new String[]{itemId}
            );
            return rowsUpdated;
    }

    public Boolean isInventoryAlreadyPresent(String inventoryName) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if the inventory already exists
        Cursor cursor = db.query(
                INVENTORY_TABLE,
                new String[]{INVENTORY_COLUMN_ID},
                "LOWER(" +INVENTORY_COLUMN_NAME + ") = LOWER(?)",
                new String[]{inventoryName.toLowerCase(Locale.ROOT)},
                null,
                null,
                null
        );

        boolean isExists = cursor.getCount() > 0;
        cursor.close();
        return isExists;
    }

    public boolean deleteInventoryById(int inventoryId) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Execute delete query
        int rowsAffected = db.delete(
                INVENTORY_TABLE,                     // Table name
                INVENTORY_COLUMN_ID + " = ?",        // WHERE clause
                new String[]{String.valueOf(inventoryId)} // WHERE arguments
        );

        // Close the database connection
        db.close();

        // Return true if any rows were affected, false otherwise
        return rowsAffected > 0;
    }

    /**
     * Registration Methods
     */

    // Insert a new user into the registration table
    public long registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(REGISTRATION_COLUMN_USERNAME, username);
        values.put(REGISTRATION_COLUMN_PASSWORD, password);

        return db.insert(REGISTRATION_TABLE, null, values);
    }

    // Authenticate user
    public boolean authenticateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                REGISTRATION_TABLE,
                new String[]{REGISTRATION_COLUMN_ID},
                REGISTRATION_COLUMN_USERNAME + "=? AND " + REGISTRATION_COLUMN_PASSWORD + "=?",
                new String[]{username, password},
                null,
                null,
                null
        );

        boolean isAuthenticated = cursor.getCount() > 0;
        cursor.close();
        return isAuthenticated;
    }

    public Long getUserId(String username, String password) {
        Long userId = null;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                REGISTRATION_TABLE,
                new String[]{REGISTRATION_COLUMN_ID},
                REGISTRATION_COLUMN_USERNAME + "=? AND " + REGISTRATION_COLUMN_PASSWORD + "=?",
                new String[]{username, password},
                null,
                null,
                null
        );

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    userId = cursor.getLong(cursor.getColumnIndexOrThrow(REGISTRATION_COLUMN_ID));
                }
            } finally {
                cursor.close(); // Ensure the cursor is closed to prevent memory leaks
            }
        }

        return userId; // Returns null if no user is found
    }

    public long updateRegisteredUserPassword(String username, String password) {

        // Check if the username already exists
        boolean isExists = isUsernameExists(username);
        SQLiteDatabase db = this.getWritableDatabase();

        if (isExists) {
            // Username exists, update the password
            ContentValues values = new ContentValues();
            values.put(REGISTRATION_COLUMN_PASSWORD, password);
            int rowsUpdated = db.update(
                    REGISTRATION_TABLE,
                    values,
                    REGISTRATION_COLUMN_USERNAME + "=?",
                    new String[]{username}
            );
            return rowsUpdated; // Return the number of rows updated
        }
        return -1; // Return -1 if the username doesn't exist
    }


    public Boolean isUsernameExists(String username) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if the username already exists
        Cursor cursor = db.query(
                REGISTRATION_TABLE,
                new String[]{REGISTRATION_COLUMN_ID},
                REGISTRATION_COLUMN_USERNAME + "=?",
                new String[]{username},
                null,
                null,
                null
        );

        boolean isExists = cursor.getCount() > 0;
        cursor.close();
        return isExists;
    }

    public Cursor fetchAllUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(
                REGISTRATION_TABLE,
                null, // Select all columns
                null, // No WHERE clause
                null, // No WHERE arguments
                null, // No GROUP BY clause
                null, // No HAVING clause
                null  // Default ORDER BY
        );
    }


    // Close the database
    public void closeDatabase() {
        if (instance != null) {
            instance.close();
            instance = null;
        }
    }
}

