package com.inventryitem.inventryitem.model;

public class UserSession {
    private static UserSession instance;
    private User user;

    private UserSession() {
        // Private constructor to prevent instantiation
    }

    // Get the single instance of UserSession
    public static synchronized UserSession getInstance() {
        if (instance == null) {
            instance = new UserSession();
        }
        return instance;
    }

    // Set the user object
    public void setUser(User user) {
        this.user = user;
    }

    // Get the user object
    public User getUser() {
        return user;
    }

    // Clear the user object (optional, e.g., on logout)
    public void clear() {
        user = null;
    }
}

