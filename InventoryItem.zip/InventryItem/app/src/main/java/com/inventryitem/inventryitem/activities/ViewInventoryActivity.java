package com.inventryitem.inventryitem.activities;


import static com.inventryitem.inventryitem.database.DatabaseHelper.INVENTORY_COLUMN_DELETE;
import static com.inventryitem.inventryitem.database.DatabaseHelper.INVENTORY_COLUMN_EDIT;
import static com.inventryitem.inventryitem.database.DatabaseHelper.INVENTORY_COLUMN_ID;
import static com.inventryitem.inventryitem.database.DatabaseHelper.INVENTORY_COLUMN_NAME;
import static com.inventryitem.inventryitem.database.DatabaseHelper.INVENTORY_COLUMN_PRICE;
import static com.inventryitem.inventryitem.database.DatabaseHelper.INVENTORY_COLUMN_QUANTITY;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.inventryitem.inventryitem.R;
import com.inventryitem.inventryitem.database.DatabaseHelper;
import com.inventryitem.inventryitem.databinding.ActivityViewInventoryBinding;
import com.inventryitem.inventryitem.model.User;
import com.inventryitem.inventryitem.model.UserSession;

public class ViewInventoryActivity extends AppCompatActivity {
    private static final String TAG = "ViewInventory";
    private DatabaseHelper databaseHelper;
    private ActivityViewInventoryBinding binding;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityViewInventoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseHelper = DatabaseHelper.getInstance(this);

        setUpData();

    }

    private void setUpData() {
        cursor = databaseHelper.fetchData(UserSession.getInstance().getUser().getUserId());
        String[] fromColumns = {INVENTORY_COLUMN_ID, INVENTORY_COLUMN_NAME, INVENTORY_COLUMN_QUANTITY, INVENTORY_COLUMN_PRICE, INVENTORY_COLUMN_EDIT, INVENTORY_COLUMN_DELETE};
        int[] toViews = {R.id.column1, R.id.column2, R.id.column3, R.id.column4, R.id.edit, R.id.delete};


        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                R.layout.list_item,
                cursor,
                fromColumns,
                toViews,
                0);

        // Set a ViewBinder to handle click listeners
        adapter.setViewBinder((view, cursor, columnIndex) -> {

            // Check if the view is the "Edit" or "Delete" TextView
            if (view.getId() == R.id.edit) {
                //sendSMS For Low Inventory ==1
                String itemId = cursor.getString(cursor.getColumnIndexOrThrow(INVENTORY_COLUMN_ID));
                view.setOnClickListener(v -> {
                    Intent intent = new Intent(ViewInventoryActivity.this, EditInventoryActivity.class);
                    intent.putExtra("itemId", itemId);
                    startActivity(intent);
                    finish();
                });
                return true;
            } else if (view.getId() == R.id.delete) {
                String itemId = cursor.getString(cursor.getColumnIndexOrThrow(INVENTORY_COLUMN_ID));

                view.setOnClickListener(v -> {
                    if (databaseHelper.deleteInventoryById(Integer.valueOf(itemId))) {
                        Toast.makeText(getApplicationContext(), "Deleted Successfully", Toast.LENGTH_SHORT).show();
                        setUpData();
                    }
                });
                return true;
            }
            return false;
        });

        binding.gridView.setAdapter(adapter);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        cursor.close();
        databaseHelper.close();
    }
}