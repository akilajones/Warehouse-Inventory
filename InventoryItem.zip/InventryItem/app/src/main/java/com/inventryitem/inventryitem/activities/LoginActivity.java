package com.inventryitem.inventryitem.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.inventryitem.inventryitem.database.DatabaseHelper;
import com.inventryitem.inventryitem.databinding.ActivityLoginBinding;
import com.inventryitem.inventryitem.model.User;
import com.inventryitem.inventryitem.model.UserSession;

import java.util.Locale;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "LoginActivity";
    private ActivityLoginBinding binding;
    private DatabaseHelper databaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
// Initialize DatabaseHelper
        databaseHelper = DatabaseHelper.getInstance(this);
        initClickListener();
    }

    private void initClickListener() {
        binding.btnLogin.setOnClickListener(this);
        binding.txtNoAccount.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == binding.btnLogin.getId()) {
            Log.d(TAG, "onClick: Login Button Clicked");
            if (validate()) {
                Log.d(TAG, "onClick: Login Successful");
                String userName = binding.userNameLayout.getEditText().getText().toString().toLowerCase(Locale.ROOT);
                String password = binding.passwordLayout.getEditText().getText().toString();
                Long userId = databaseHelper.getUserId(userName, password);
                UserSession.getInstance().setUser(new User(userId, userName, password));
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            } else {
                Log.d(TAG, "onClick: Login Failed");
            }
        } else if (v.getId() == binding.txtNoAccount.getId()) {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        }

    }

    private boolean validate() {
        String userName = binding.userNameLayout.getEditText().getText().toString().toLowerCase(Locale.ROOT);
        String password = binding.passwordLayout.getEditText().getText().toString();

        binding.userNameLayout.setError(null);
        binding.passwordLayout.setError(null);
        if (userName.isEmpty()) {
            binding.userNameLayout.setError("Please enter User Name");
            return false;
        } else if (password.isEmpty()) {
            binding.passwordLayout.setError("Please enter Password");
            return false;
        }else if (!databaseHelper.authenticateUser(userName,password)){
            binding.userNameLayout.setError("Invalid Credentials");
            return false;
        }
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close the database when the activity is destroyed
        databaseHelper.closeDatabase();
    }
}