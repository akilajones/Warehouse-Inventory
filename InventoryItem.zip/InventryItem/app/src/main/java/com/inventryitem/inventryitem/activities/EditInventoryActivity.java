package com.inventryitem.inventryitem.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.inventryitem.inventryitem.R;
import com.inventryitem.inventryitem.database.DatabaseHelper;
import com.inventryitem.inventryitem.databinding.ActivityAddInventoryBinding;
import com.inventryitem.inventryitem.databinding.ActivityEditInventoryBinding;
import com.inventryitem.inventryitem.model.Inventory;

public class EditInventoryActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "AddInventoryActivity";
    private ActivityEditInventoryBinding binding;
    private DatabaseHelper databaseHelper;
    private String itemId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityEditInventoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseHelper = DatabaseHelper.getInstance(this);
        
        itemId = getIntent().getStringExtra("itemId");
        updateView();
        initClickListener();
    }

    private void updateView() {
        Inventory inventory = databaseHelper.getInventoryById(itemId);
        binding.inventoryName.getEditText().setText(inventory.getName());
        binding.inventoryPrice.getEditText().setText(inventory.getPrice());
        binding.inventoryQuantity.getEditText().setText(inventory.getQuantity());

    }

    private void initClickListener(){
        binding.btnUpdateInventory.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == binding.btnUpdateInventory.getId()) {
            if(validate()){
                databaseHelper.updateInventory(
                        itemId,
                        binding.inventoryName.getEditText().getText().toString(),
                        binding.inventoryQuantity.getEditText().getText().toString(),
                        binding.inventoryPrice.getEditText().getText().toString()
                );


                binding.inventoryName.getEditText().setText("");
                binding.inventoryPrice.getEditText().setText("");
                binding.inventoryQuantity.getEditText().setText("");

                Toast.makeText(getApplicationContext(), "Inventory updated Successfully", Toast.LENGTH_SHORT).show();

                finish();
            }
        }

    }

    private boolean validate() {
        binding.inventoryName.setError(null);
        binding.inventoryPrice.setError(null);
        binding.inventoryQuantity.setError(null);

        String name = binding.inventoryName.getEditText().getText().toString();
        String price = binding.inventoryPrice.getEditText().getText().toString();
        String quantity = binding.inventoryQuantity.getEditText().getText().toString();
        if(name.isEmpty()){
            binding.inventoryName.setError("Invalid Name");
            return false;
        }else if(price.isEmpty()){
            binding.inventoryPrice.setError("Invalid Price");
            return false;
        }else if(quantity.isEmpty()){
            binding.inventoryQuantity.setError("Invalid Quantity");
            return false;
        }

        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close the database when the activity is destroyed
        databaseHelper.closeDatabase();
    }
}
