package com.inventryitem.inventryitem.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.inventryitem.inventryitem.database.DatabaseHelper;
import com.inventryitem.inventryitem.databinding.ActivityMainBinding;
import com.inventryitem.inventryitem.model.Inventory;
import com.inventryitem.inventryitem.model.UserSession;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "MainActivity";
    private ActivityMainBinding binding;
    private DatabaseHelper databaseHelper;
    private static final int SMS_PERMISSION_REQUEST_CODE = 101;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize DatabaseHelper
        databaseHelper = DatabaseHelper.getInstance(this);
        initClickListener();
        setupData();
        checkAndRequestSMSPermission();
    }

    private void setupData() {
        binding.txtWelcome.setText("Welcome! " + UserSession.getInstance().getUser().getUserName());
    }

    private void initClickListener() {
        binding.btnAddInventory.setOnClickListener(this);
        binding.btnViewInventory.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == binding.btnAddInventory.getId()) {
            Intent intent = new Intent(this, AddInventoryActivity.class);
            startActivity(intent);
        }else if (v.getId() == binding.btnViewInventory.getId()) {
            Intent intent = new Intent(this, ViewInventoryActivity.class);
            startActivity(intent);
        }

    }

    // Check if SMS permission is granted
    private void checkAndRequestSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            fetchInventoryDataAndSendSMS();
            // Permission granted, send SMS
        } else {
            // Request permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        }
    }

    private void fetchInventoryDataAndSendSMS() {
        List<Inventory> inventoryList = databaseHelper.fetchInventoryList(UserSession.getInstance().getUser().getUserId());
        for (Inventory inventory : inventoryList) {
            if(Integer.parseInt(inventory.getQuantity())<=1){
                sendSMSNotification("Your Inventory Item ''"+inventory.getName()+"'' is Considered as Low");
            }
        }


    }

    // Method to send SMS notification
    private void sendSMSNotification(String message) {
        try {
            String phoneNumber = "1234567890"; // Replace with the user's phone number

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS notification sent successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS. " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close the database when the activity is destroyed
        databaseHelper.closeDatabase();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, send SMS
                fetchInventoryDataAndSendSMS();
            } else {
                // Permission denied
                Toast.makeText(this, "SMS permission denied. Notifications will not be sent via SMS.", Toast.LENGTH_SHORT).show();
            }
        }
    }

}