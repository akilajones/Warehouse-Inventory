package com.inventryitem.inventryitem.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.inventryitem.inventryitem.R;
import com.inventryitem.inventryitem.database.DatabaseHelper;
import com.inventryitem.inventryitem.databinding.ActivityRegisterBinding;

import java.util.Locale;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "RegisterActivity";
    private ActivityRegisterBinding binding;
    private DatabaseHelper databaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize DatabaseHelper
        databaseHelper = DatabaseHelper.getInstance(this);
        initClickListener();
    }

    private void initClickListener() {
        binding.btnRegistration.setOnClickListener(this);
        binding.txtAlreadyAccount.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == binding.btnRegistration.getId()) {
            Log.d(TAG, "onClick: Registration Button Clicked");
            if (validate()) {
                Log.d(TAG, "onClick: Registration Successful");
                String userName = binding.userNameLayout.getEditText().getText().toString().toLowerCase(Locale.ROOT);
                String password = binding.passwordLayout.getEditText().getText().toString();
                databaseHelper.registerUser(userName, password);
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            } else {
                Log.d(TAG, "onClick: Registration Failed");
            }
        } else if (v.getId() == binding.txtAlreadyAccount.getId()) {
            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
            startActivity(intent);
        }
    }

    private boolean validate() {
        String userName = binding.userNameLayout.getEditText().getText().toString().toLowerCase(Locale.ROOT);
        String password = binding.passwordLayout.getEditText().getText().toString();
        String confirmPassword = binding.confirmPasswordLayout.getEditText().getText().toString();

        binding.userNameLayout.setError(null);
        binding.passwordLayout.setError(null);
        binding.confirmPasswordLayout.setError(null);
        if (userName.isEmpty()) {
            binding.userNameLayout.setError("Please enter User Name");
            return false;
        } else if (password.isEmpty()) {
            binding.passwordLayout.setError("Please enter Password");
            return false;
        } else if (confirmPassword.isEmpty()) {
            binding.confirmPasswordLayout.setError("Please enter" +
                    " Confirm Password");
            return false;
        } else if (!password.equals(confirmPassword)) {
            binding.confirmPasswordLayout.setError("Password and Confirm Password should be same");
            return false;
        } else if (databaseHelper.isUsernameExists(userName)) {
            binding.userNameLayout.setError("Username already exists");
            return false;
        }
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close the database when the activity is destroyed
        databaseHelper.closeDatabase();
    }

}